void isort(int a[], int n);  // insertion sort
void ssort(int a[], int n);  // selection sort
void ssortMax(int a[], int n);

void mergesortASD(int a[], int n);

void scambia(int * arr, int i1, int i2);